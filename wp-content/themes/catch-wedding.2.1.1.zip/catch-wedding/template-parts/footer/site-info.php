<?php
/**
 * The template used for displaying credits
 *
 * @package Catch_Wedding
 */
?>

<?php
/**
 * catch_wedding_credits hook
 * @hooked catch_wedding_footer_content - 10
 */
do_action( 'catch_wedding_credits' );

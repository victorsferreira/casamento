<?php
/**
 * The template used for displaying slider
 *
 * @package Catch_Wedding
 */
?>

<?php
/**
 * catch_wedding_slider hook
 * @hooked catch_wedding_featured_slider - 10
 */
do_action( 'catch_wedding_slider' );

<?php
/**
 * Display Header Media
 *
 * @package Catch_Wedding
 */

catch_wedding_featured_overall_image();

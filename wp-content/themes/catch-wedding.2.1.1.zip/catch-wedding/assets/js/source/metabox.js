jQuery(document).ready(function(){jQuery("#catch-wedding-ui-tabs").tabs()});
